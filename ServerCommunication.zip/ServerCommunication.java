import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.HashMap;


public class ServerCommunication {
    
    

    public ServerCommunication(){
    }

    public String toURLUser(String group, String name, int score){
        return String.format("http://localhost:8080/user?group=%s&name=%s&score=%d", group,name,score);
    }
    public String toURLGroup(String group, String rythm){
        return String.format("http://localhost:8080/group?rythmname=%s&rythm=%s", group, rythm);
    }
    public String toURLScoreboard(String name){
        return String.format("http://localhost:8080/scoreboard?rythmname=%s", name);
    }

    public void addUserToDatabase(String group, String name, int score)throws Exception{
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(toURLUser(group, name, score)))
            .build();
        client.send(request, BodyHandlers.ofString());
        
    }

    public void addGroupToDatabase(String group, String rythm)throws Exception{
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(toURLGroup(group, rythm)))
            .build();
        client.send(request, BodyHandlers.ofString());
        
    }

    public HashMap<String, Integer> getScoreboard(String name) throws Exception{
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(toURLScoreboard(name)))
            .build();

        HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
        HashMap<String, Integer> map = toMap(response.body());
        return map;
        
    }

    public HashMap<String, Integer> toMap(String file){
        String newString = file.substring(file.indexOf("[")+1,file.indexOf("]"));
        HashMap<String, Integer> map = new HashMap<>();
        int counter = 0;
        ArrayList<Integer> placesfront = new ArrayList<>();
        ArrayList<Integer> placesend = new ArrayList<>();

        //locates all the different users and adds the front and end to a array.
        for (int i=0; i<newString.length(); i++){
            if (newString.charAt(i) == '{'){
                placesfront.add(i);
                counter++;
            }
            if (newString.charAt(i) == '}'){
                placesend.add(i);
            }
        }
        //put name and score to a hashmap
        for (int i =0; i<counter; i++){
            String input = newString.substring(placesfront.get(i), placesend.get(i)+1);
            String name = input.substring(input.indexOf(":")+2, input.indexOf(",")-1);
            String score = input.substring(input.indexOf(":", input.indexOf(":")+1)+1, input.indexOf("}"));
            map.put(name, Integer.parseInt(score));
        }
        return map;

        
    }

    

}
