package com.example.timingtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    int counter;
    MediaPlayer playerHigh;
    MediaPlayer playerLow;
    long startTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void soundHigh() {
        playerHigh.start();
    }

    private void soundLow() {
        playerLow.start();
    }

    private void start(double bpm, int measure, int bars) {
        counter = 0;

        while(counter < bars*measure){
            long timePassed = System.nanoTime();
            if(timePassed >= startTime + 1000000000*(60.0/bpm)){
                if (counter%measure==0){
                    soundHigh();
                    System.out.println("TICK");
                }else{
                    soundLow();
                    System.out.println("TOCK");
                }
                counter++;
                startTime = System.nanoTime();
            }
        }
    }

    public void play(View view) {
        if(playerHigh == null) {
            playerHigh = MediaPlayer.create(this, R.raw.high);
            playerHigh.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopPlayerHigh();
                }
            });
        }
        if(playerLow == null) {
            playerLow = MediaPlayer.create(this, R.raw.click);
            playerLow.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopPlayerLow();
                }
            });
        }

        start(140, 5, 8);
    }

    private void stopPlayerHigh() {
        if(playerHigh != null) {
            playerHigh.release();
            playerHigh = null;
        }
    }

    private void stopPlayerLow() {
        if(playerLow != null) {
            playerLow.release();
            playerLow = null;
        }
    }
}

