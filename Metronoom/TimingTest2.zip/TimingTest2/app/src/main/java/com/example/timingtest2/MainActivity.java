package com.example.timingtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    MediaPlayer playerHigh;
    MediaPlayer playerMid;
    MediaPlayer playerLow;
    long startTime;

    boolean preCount;
    boolean stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void soundHigh() {
        playerHigh.start();
    }
    private void soundMid() {
        playerMid.start();
    }
    private void soundLow() {
        playerLow.start();
    }

    private void start(double bpm, int measure, int bars, boolean eight) {
        int counter = 0;

        if(eight){
            int internalCounter = 0;
            while(counter < bars*measure+measure && !stop){
                long timePassed = System.nanoTime();
                if(timePassed >= startTime + 1000000000*(60.0/bpm)/2){
                    if (counter%measure==0){
                        soundHigh();
                        internalCounter = 0;
                    } else if(internalCounter%2==0) {
                        soundMid();
                    } else {
                        soundLow();
                    }
                    counter++;
                    internalCounter++;
                    startTime = System.nanoTime();
                    if(counter == measure) {
                        preCount = false;
                        System.out.println("Go");
                    }
                }
            }
        } else {
            while(counter < bars*measure+measure && !stop){
                long timePassed = System.nanoTime();
                if(timePassed >= startTime + 1000000000*(60.0/bpm)){
                    if (counter%measure==0){
                        soundHigh();
                    } else {
                        soundLow();
                    }
                    counter++;
                    startTime = System.nanoTime();
                    if(counter == measure) {
                        preCount = false;
                        System.out.println("Go");
                    }
                }
            }
        }
    }

    public void play(View view) {
        if(playerHigh == null) {
            playerHigh = MediaPlayer.create(this, R.raw.high);
        }
        if(playerMid == null) {
            playerMid = MediaPlayer.create(this, R.raw.mid);
        }
        if(playerLow == null) {
            playerLow = MediaPlayer.create(this, R.raw.click);
        }

        stop = false;
        preCount = true;

        new Thread(new Runnable() {
            @Override
            public void run() {
                start(160, 7, 8, true);

                try {
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                stopPlayerHigh();
                stopPlayerMid();
                stopPlayerLow();
            }
        }).start();
    }

    public void stop(View view) {
        stop = true;
    }

    private void stopPlayerHigh() {
        if(playerHigh != null) {
            playerHigh.release();
            playerHigh = null;
        }
    }

    private void stopPlayerMid() {
        if(playerMid != null) {
            playerMid.release();
            playerMid = null;
        }
    }

    private void stopPlayerLow() {
        if(playerLow != null) {
            playerLow.release();
            playerLow = null;
        }
    }
}

